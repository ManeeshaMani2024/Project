package com.example.demo_rest;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DemoRestController {
	public DemoRestController() {
		System.out.println("Constructor DemoCOntroller()");
	}
	@GetMapping("/abcd")
	String met() {
		System.out.println("-----j-----");
		return "HelloWorld";
	}
@GetMapping("/ticket")
Ticket getUser(@RequestParam("tid")int ticketid) {
return new Ticket(ticketid,"SomeUser","Some addres", 2);
}
@PostMapping("/book")
Ticket bookTicket(@RequestBody Ticket ticket) {
	
	ticket.setId(100);
	return ticket;
}
@DeleteMapping("/cancel")
String cancelTicket(@RequestParam("id") int ticketid) {
	return "Ticket with id"+ticketid+"Is cancelled";
}
}
